module.exports = {
  id: "llama-shell-tool",
  name: "Llama Shell Tool",
  description: "Appelle le modèle llama3.2:3b localement pour générer des commandes shell",
  register(api) {
    api.registerTool({
      name: "call_llama_shell",
      description: "Génère une commande shell via Llama 3.2:3B (réponse concise)",
      parameters: {
        type: "object",
        properties: {
          prompt: { type: "string", description: "La question ou commande en français ou anglais" }
        },
        required: ["prompt"]
      },
      async execute(_id, { prompt }) {
        try {
          // Construction du prompt système + utilisateur
          const systemPrompt = `Tu es un assistant spécialisé dans la génération de commandes shell Linux.
- Réponds uniquement par la commande brute, sans aucun texte autour.
- N'ajoute jamais de formules de politesse, d'explications, ni de backticks.
- Pour une instruction en français, convertis-la en commande shell.
- Si l'instruction est déjà une commande valide, répète-la telle quelle.
- Utilise des commandes simples et directes quand c'est possible.
- Pour "archive", utilise tar ou zip, pas rm.
- Pour "backup", spécifie le nom de l'archive.
- Exemples :
 "liste les fichiers" → "ls"
 "affiche le contenu de fichier.txt" → "cat fichier.txt"
 "mv ancien nouveau" → "mv ancien nouveau"
 "combien de RAM" → "free -m"
 "charge CPU" → "top -b -n 1 | grep Cpu"
 "backup de /etc" → "tar -czf etc-backup.tar.gz /etc"
 "archive les logs" → "tar -czf logs-$(date +%Y%m).tar.gz /var/log/*.log"
 "5 plus gros fichiers" → "find . -type f -exec du -h {} + | sort -rh | head -5"`;

          const fullPrompt = `${systemPrompt}\n\nUtilisateur : ${prompt}\nAssistant :`;

          const res = await fetch("http://127.0.0.1:11434/api/generate", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              model: "llama3.2:3b",
              prompt: fullPrompt,
              stream: false,
              options: {
                num_ctx: 512, // réduction du contexte pour économiser RAM
                num_thread: 2,
                temperature: 0.1, // réduit la créativité (hallucinations)
                top_k: 10,
                top_p: 0.9
              }
            })
          });
          const data = await res.json();
          let answer = data.response || "Pas de réponse";
          // Nettoyage supplémentaire : supprime les "Sure, ..." résiduels
          answer = answer.replace(/^(Sure|Of course|Here's|Voici|Bien sûr)[,:]?\s*/i, "");
          return { content: [{ type: "text", text: answer.trim() }] };
        } catch (err) {
          return { content: [{ type: "text", text: "Erreur : Ollama indisponible" }] };
        }
      }
    });
  }
};
