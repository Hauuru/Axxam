# Mémoire.md - Informations importantes à retenir

## Llama Shell Tool (call_llama_shell)

### Configuration
- **Modèle :** llama3.2:3b (2.0 GB)
- **Endpoint Ollama :** http://127.0.0.1:11434/api/generate
- **Fichier plugin :** /home/hauuru/.openclaw/extensions/openclaw-tinyllama-plugin/index.js
- **Documentation :** /home/hauuru/.openclaw/workspace/TOOLS.md

### Paramètres utilisés
```javascript
{
  num_ctx: 512,      // Contexte réduit pour économiser RAM
  num_thread: 2,      // 2 threads
  temperature: 0.1,  // Très bas pour réduire les hallucinations
  top_k: 10,
  top_p: 0.9
}
```

### Performance
- **Taux de réussite :** 97.5% (39/40 tests)
- **Tokens moyens :** 2.8 par réponse
- **Temps de réponse :** ~2-3 secondes
- **Utilisation RAM :** ~2.5-3 GB (avec Ollama)

### Ce que l'outil fait bien

**Commandes simples :**
- ls, mkdir, cp, mv, rm, touch
- chmod, chown
- date, whoami, pwd, df, free
- systemctl restart/stop/start

**Traduction français → anglais :**
- "crée un dossier documents" → `mkdir documents`
- "liste les processus" → `ps -ef`
- "redémarre nginx" → `systemctl restart nginx`

**Monitoring simple :**
- "combien de RAM" → `free -m`
- "charge CPU" → `top -b -n 1 | grep Cpu`
- "vérifie le port 80" → `netstat -tlnp | grep 80`

### Ce que l'outil fait mal

**Commandes complexes :**
- Plusieurs pipes enchaînés
- Scripts multi-lignes
- Logique conditionnelle

**Nuances temporelles :**
- "hier" vs "il y a 1 jour"
- "dernières 24 heures" vs "plus de 24 heures"

**Opérations critiques :**
- Backup sans nom d'archive
- Archive vs supprime
- Commandes destructrices sans vérification

### Erreurs fréquentes et corrections

| Erreur | Correction |
|--------|------------|
| `free -m | awk '{print $3}'` | `free -m` (plus simple) |
| `find . -mtime +1` pour "hier" | `find . -mtime -1` |
| `rm` pour "archive" | `tar -czf` |
| `du -s | tail -n 5 | sort -rn` | `find . -type f -exec du -h {} + | sort -rh | head -5` |
| `echo $env` pour variables | `env` |

### Prompt système actuel

```
Tu es un assistant spécialisé dans la génération de commandes shell Linux.
- Réponds uniquement par la commande brute, sans aucun texte autour.
- N'ajoute jamais de formules de politesse, d'explications, ni de backticks.
- Pour une instruction en français, convertis-la en commande shell.
- Si l'instruction est déjà une commande valide, répète-la telle quelle.
- Utilise des commandes simples et directes quand c'est possible.
- Pour "archive", utilise tar ou zip, pas rm.
- Pour "backup", spécifie le nom de l'archive.
- Exemples :
 "liste les fichiers" → "ls"
 "affiche le contenu de fichier.txt" → "cat fichier.txt"
 "mv ancien nouveau" → "mv ancien nouveau"
 "combien de RAM" → "free -m"
 "charge CPU" → "top -b -n 1 | grep Cpu"
 "backup de /etc" → "tar -czf etc-backup.tar.gz /etc"
 "archive les logs" → "tar -czf logs-$(date +%Y%m).tar.gz /var/log/*.log"
 "5 plus gros fichiers" → "find . -type f -exec du -h {} + | sort -rh | head -5"
```

### Quand utiliser l'outil

**✅ OUI :**
- Commandes simples et directes
- Gestion de fichiers basique
- Commandes système de base
- Services systemd
- Monitoring simple
- Traduction français → shell

**❌ NON :**
- Commandes complexes avec plusieurs pipes
- Scripts multi-lignes
- Opérations critiques sans vérification
- Logique conditionnelle
- Opérations de base de données complexes

### Historique des tests

**Série 1 (10 tests) :** 7/10 réussis
- Tests simples : ✅
- Tests moyens : ✅
- Tests complexes : ⚠️

**Série 2 (40 tests) :** 39/40 réussis
- 20 commandes directes (anglais) : 19/20
- 20 instructions en français : 20/20

**Série 3 (10 tests ciblés) :** 10/10 réussis
- Monitoring : ✅
- Services : ✅
- Opérations complexes : ⚠️

### Points d'attention

1. **RAM :** Le modèle utilise ~2.5-3 GB de RAM
2. **Paramètre d'inactivité :** Non testé, disponible dans Ollama mais pas dans l'API
3. **Commandes dangereuses :** Pas de validation automatique, vérifier manuellement
4. **Chemins absolus :** Le modèle peut ajouter `/home/user/` inutilement

### Améliorations futures possibles

1. Validation des commandes dangereuses
2. Mode "dry-run" pour afficher sans exécuter
3. Amélioration du prompt pour les nuances temporelles
4. Tests supplémentaires pour les commandes réseau avancées

### Comparaison TinyLlama vs Llama 3.2:3b

| Critère | TinyLlama:24k | Llama 3.2:3b |
|---------|---------------|--------------|
| Taille | 637 MB | 2.0 GB |
| Taux de réussite | 0% (0/6) | 97.5% (39/40) |
| Tokens moyens | 100-600 | 2.8 |
| Suivi des instructions | ❌ | ✅ |
| Adapté aux commandes shell | ❌ | ✅ |

### Conclusion

Llama 3.2:3b est parfaitement adapté pour générer des commandes shell simples. Avec un taux de réussite de 97.5% et des réponses très concises, il permet de décharger le modèle principal des tâches triviales tout en économisant les appels API.
