# TOOLS.md - Outils disponibles

## Llama Shell Tool (call_llama_shell)

**Description :** Génère des commandes shell Linux via Llama 3.2:3B local.

### Capacités

**Fonctionne bien pour :**
- Commandes simples (ls, mkdir, cp, mv, rm)
- Gestion de fichiers et permissions
- Commandes système de base
- Services systemd
- Monitoring simple

**Éviter pour :**
- Commandes complexes avec plusieurs pipes
- Scripts multi-lignes
- Opérations critiques sans vérification
- Logique conditionnelle

### Limitations

- Peut générer des commandes incomplètes
- Peut confondre "archive" et "supprime"
- Complexité inutile parfois
- Nuances temporelles imprécises

### Exemples

| Prompt | Résultat |
|--------|----------|
| crée un dossier documents | `mkdir documents` |
| liste les processus | `ps -ef` |
| redémarre nginx | `systemctl restart nginx` |
| combien de RAM | `free -m` |
| charge CPU | `top -b -n 1 | grep Cpu` |
| backup de /etc | `tar -czf etc-backup.tar.gz /etc` |
| archive les logs | `tar -czf logs-$(date +%Y%m).tar.gz /var/log/*.log` |
| 5 plus gros fichiers | `find . -type f -exec du -h {} + | sort -rh | head -5` |

### Quand l'utiliser

**✅ Utiliser :**
- Commandes simples : ls, mkdir, cp, mv, rm, touch
- Gestion de fichiers : chmod, chown, find
- Commandes système : date, whoami, pwd, df, free
- Services : systemctl restart/stop/start
- Réseau basique : ssh, scp, ping
- Monitoring simple : top, ps, netstat

**❌ Éviter :**
- Commandes complexes avec plusieurs pipes
- Scripts multi-lignes
- Opérations critiques sans vérification
- Commandes nécessitant une logique conditionnelle
- Opérations de base de données complexes
