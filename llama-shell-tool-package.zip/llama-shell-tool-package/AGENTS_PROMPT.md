# Prompt à injecter dans AGENTS.md

Copiez ce contenu et ajoutez-le à votre fichier `AGENTS.md` dans la section appropriée (par exemple "Outils disponibles" ou créez une nouvelle section "Llama Shell Tool").

---

## Llama Shell Tool (call_llama_shell)

### Description

Llama Shell Tool est un outil qui génère des commandes shell Linux via le modèle Llama 3.2:3b exécuté localement via Ollama. Il permet de décharger les tâches triviales de génération de commandes du modèle principal.

### Quand utiliser cet outil

**Utilisez call_llama_shell pour :**
- Générer des commandes shell simples (ls, mkdir, cp, mv, rm, touch)
- Traduire des instructions en français vers des commandes shell
- Obtenir des commandes de gestion de fichiers (chmod, chown, find)
- Générer des commandes système de base (date, whoami, pwd, df, free)
- Obtenir des commandes pour les services (systemctl restart/stop/start)
- Générer des commandes de monitoring simple (top, ps, netstat)

**N'utilisez PAS call_llama_shell pour :**
- Commandes complexes avec plusieurs pipes
- Scripts multi-lignes
- Opérations critiques sans vérification
- Commandes nécessitant une logique conditionnelle
- Opérations de base de données complexes

### Comment l'utiliser

**Syntaxe :**
```
Utilise call_llama_shell pour "[votre instruction en français ou anglais]"
```

**Exemples :**
```
Utilise call_llama_shell pour "crée un dossier documents"
Utilise call_llama_shell pour "liste les processus"
Utilise call_llama_shell pour "redémarre nginx"
Utilise call_llama_shell pour "combien de RAM est utilisée"
```

### Résultats attendus

L'outil renvoie une commande shell brute, sans explication ni texte autour.

**Exemples de réponses :**
- "crée un dossier documents" → `mkdir documents`
- "liste les processus" → `ps -ef`
- "redémarre nginx" → `systemctl restart nginx`
- "combien de RAM" → `free -m`

### Limitations

- Peut générer des commandes incomplètes pour les backups
- Peut confondre "archive" et "supprime"
- Peut ajouter une complexité inutile
- Ne comprend pas les nuances temporelles précises
- Ne valide pas les commandes dangereuses

### Points d'attention

1. **Vérifiez toujours les commandes générées** avant de les exécuter
2. **Pour les commandes dangereuses** (rm -rf, dd, mkfs), demandez confirmation à l'utilisateur
3. **L'outil utilise ~2.5-3 GB de RAM** avec Ollama
4. **Ollama doit être en cours d'exécution** pour que l'outil fonctionne

### Fallback si le plugin n'est pas installé

Si l'outil `call_llama_shell` n'est pas disponible, vous pouvez :

1. **Générer directement la commande** en utilisant vos connaissances
2. **Demander à l'utilisateur** de vérifier que le plugin est installé
3. **Utiliser le modèle principal** pour générer la commande (moins efficace mais fonctionnel)

**Exemple de fallback :**
```
L'outil call_llama_shell n'est pas disponible. Je vais générer la commande directement :
Pour "crée un dossier documents", la commande est : mkdir documents
```

### Intégration dans le workflow

**Workflow recommandé :**
1. L'utilisateur demande une commande en français ou anglais
2. Utilisez `call_llama_shell` pour générer la commande
3. Vérifiez que la commande est correcte et sûre
4. Exécutez la commande (ou demandez confirmation si elle est dangereuse)
5. Présentez le résultat à l'utilisateur

**Exemple de workflow complet :**
```
Utilisateur : "Comment je peux créer un dossier documents ?"

Agent :
1. J'utilise call_llama_shell pour "crée un dossier documents"
2. Réponse : mkdir documents
3. Vérification : commande simple et sûre
4. Exécution : mkdir documents
5. Résultat : Dossier créé avec succès
```

### Performance

- **Taux de réussite :** 97.5% (39/40 tests)
- **Tokens moyens :** 2.8 par réponse
- **Temps de réponse :** ~2-3 secondes

### Documentation supplémentaire

- **TOOLS.md** : Guide d'utilisation détaillé
- **mémoire.md** : Informations opérationnelles et erreurs fréquentes

---

**Note :** Ce prompt est conçu pour être intégré dans AGENTS.md et permettre à l'agent d'utiliser Llama Shell Tool même si le plugin n'est pas complètement installé, en fournissant un fallback approprié.
