# Llama Shell Tool - Package d'installation

## 📦 Contenu

Ce package contient tout ce qu'il faut pour intégrer Llama 3.2:3b comme générateur de commandes shell dans OpenClaw.

```
llama-shell-tool-package/
├── MANUEL.md              # Manuel d'installation complet
├── AGENTS_PROMPT.md       # Prompt à injecter dans AGENTS.md
├── TOOLS.md               # Documentation de l'outil
├── mémoire.md             # Informations opérationnelles
└── plugin/
    └── index.js           # Le plugin OpenClaw
```

## 🚀 Installation rapide

1. **Lisez le manuel** : `MANUEL.md`
2. **Copiez le plugin** au bon emplacement
3. **Intégrez le prompt** dans AGENTS.md
4. **Redémarrez OpenClaw**

## 📋 Emplacements critiques

### Plugin (obligatoire)

```
/home/hauuru/.openclaw/extensions/openclaw-tinyllama-plugin/index.js
```

### Documentation (optionnel mais recommandé)

```
/home/hauuru/.openclaw/workspace/TOOLS.md
/home/hauuru/.openclaw/workspace/mémoire.md
```

### AGENTS.md (pour intégration)

```
/home/hauuru/.openclaw/workspace/AGENTS.md
```

## ⚠️ Points importants

1. **Le nom du dossier du plugin doit être exact** : `openclaw-tinyllama-plugin`
2. **Le fichier doit s'appeler** : `index.js`
3. **Ollama doit être en cours d'exécution** pour que l'outil fonctionne
4. **Le modèle llama3.2:3b doit être installé** dans Ollama

## 🧪 Test rapide

Après installation, testez avec :

```
Utilise call_llama_shell pour "liste les fichiers"
```

La réponse devrait être : `ls` ou `ls -la`

## 📚 Documentation

- **MANUEL.md** : Guide d'installation complet avec dépannage
- **AGENTS_PROMPT.md** : Prompt à injecter dans AGENTS.md
- **TOOLS.md** : Guide d'utilisation de l'outil
- **mémoire.md** : Informations opérationnelles et erreurs fréquentes

## 🎯 Capacités de l'outil

**Fonctionne bien pour :**
- ✅ Commandes simples (ls, mkdir, cp, mv, rm)
- ✅ Gestion de fichiers et permissions
- ✅ Commandes système de base
- ✅ Services systemd
- ✅ Monitoring simple
- ✅ Traduction français → anglais (shell)

**Éviter pour :**
- ❌ Commandes complexes avec plusieurs pipes
- ❌ Scripts multi-lignes
- ❌ Opérations critiques sans vérification
- ❌ Logique conditionnelle

## 📊 Performance

- **Taux de réussite :** 97.5% (39/40 tests)
- **Tokens moyens :** 2.8 par réponse
- **Temps de réponse :** ~2-3 secondes
- **RAM utilisée :** ~2.5-3 GB

## 💡 Prochaines étapes

1. ✅ Lire MANUEL.md
2. ✅ Installer le plugin
3. ✅ Intégrer le prompt dans AGENTS.md
4. ✅ Tester avec des commandes simples
5. ✅ Consulter TOOLS.md et mémoire.md

---

**Version :** 1.0
**Date :** 2026-04-03
**Modèle :** llama3.2:3b
**Plugin :** openclaw-tinyllama-plugin
