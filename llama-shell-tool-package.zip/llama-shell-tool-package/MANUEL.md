# Manuel d'installation - Llama Shell Tool

## 📦 Contenu du package

Ce package contient tout ce qu'il faut pour intégrer Llama 3.2:3b comme générateur de commandes shell dans OpenClaw.

**Fichiers inclus :**
- `plugin/index.js` - Le plugin OpenClaw
- `TOOLS.md` - Documentation de l'outil
- `mémoire.md` - Informations opérationnelles
- `AGENTS_PROMPT.md` - Prompt à injecter dans AGENTS.md

## 🎯 Prérequis

1. **Ollama installé et fonctionnel**
   ```bash
   ollama list
   ```
   Doit afficher `llama3.2:3b` dans la liste

2. **Ollama en cours d'exécution**
   ```bash
   ollama serve
   ```

3. **OpenClaw installé**

## 📁 Emplacement du plugin

Le plugin doit être installé à cet emplacement exact :

```
/home/hauuru/.openclaw/extensions/openclaw-tinyllama-plugin/index.js
```

**Important :** Le nom du dossier `openclaw-tinyllama-plugin` et du fichier `index.js` sont importants pour qu'OpenClaw reconnaisse le plugin.

## 🔧 Installation

### Étape 1 : Créer le dossier du plugin

```bash
mkdir -p /home/hauuru/.openclaw/extensions/openclaw-tinyllama-plugin
```

### Étape 2 : Copier le plugin

```bash
cp plugin/index.js /home/hauuru/.openclaw/extensions/openclaw-tinyllama-plugin/index.js
```

### Étape 3 : Copier la documentation (optionnel)

```bash
cp TOOLS.md /home/hauuru/.openclaw/workspace/TOOLS.md
cp mémoire.md /home/hauuru/.openclaw/workspace/mémoire.md
```

### Étape 4 : Redémarrer OpenClaw

```bash
openclaw gateway restart
```

Ou si vous utilisez le mode local, redémarrez simplement votre session.

## 🧪 Vérification de l'installation

Une fois OpenClaw redémarré, testez l'outil avec une commande simple :

```
Utilise call_llama_shell pour générer la commande "liste les fichiers"
```

La réponse devrait être : `ls` ou `ls -la`

## 📝 Intégration dans AGENTS.md

Pour que l'agent puisse utiliser l'outil même si le plugin n'est pas complètement installé, ajoutez le contenu de `AGENTS_PROMPT.md` à votre fichier `AGENTS.md`.

**Emplacement de AGENTS.md :**
```
/home/hauuru/.openclaw/workspace/AGENTS.md
```

**Où ajouter le prompt :**
Ajoutez-le à la section "Outils disponibles" ou créez une nouvelle section "Llama Shell Tool".

## ⚠️ Points d'attention

### 1. RAM utilisée

Le modèle Llama 3.2:3b utilise environ **2.5-3 GB de RAM** avec Ollama.

Vérifiez que votre machine a suffisamment de RAM disponible :

```bash
free -h
```

### 2. Paramètre d'inactivité

Le paramètre d'arrêt automatique pour économiser la RAM est disponible dans Ollama mais **pas dans l'API**. Il doit être configuré au niveau d'Ollama, pas du plugin.

### 3. Commandes dangereuses

Le plugin **ne valide pas** automatiquement les commandes dangereuses. Vérifiez toujours les commandes générées avant de les exécuter.

## 🚀 Utilisation

### Exemples d'utilisation

**Commandes simples :**
```
Utilise call_llama_shell pour "crée un dossier documents"
```
→ `mkdir documents`

**Commandes système :**
```
Utilise call_llama_shell pour "combien de RAM est utilisée"
```
→ `free -m`

**Services :**
```
Utilise call_llama_shell pour "redémarre nginx"
```
→ `systemctl restart nginx`

### Ce que l'outil fait bien

✅ Commandes simples (ls, mkdir, cp, mv, rm)
✅ Gestion de fichiers et permissions
✅ Commandes système de base
✅ Services systemd
✅ Monitoring simple
✅ Traduction français → anglais (shell)

### Ce que l'outil fait mal

❌ Commandes complexes avec plusieurs pipes
❌ Scripts multi-lignes
❌ Opérations critiques sans vérification
❌ Logique conditionnelle

## 📊 Performance

- **Taux de réussite :** 97.5% (39/40 tests)
- **Tokens moyens :** 2.8 par réponse
- **Temps de réponse :** ~2-3 secondes
- **Taille du modèle :** 2.0 GB

## 🐛 Dépannage

### Problème : "Erreur : Ollama indisponible"

**Solution :**
```bash
# Vérifiez qu'Ollama tourne
ps aux | grep ollama

# Si ce n'est pas le cas, démarrez-le
ollama serve
```

### Problème : "Modèle non trouvé"

**Solution :**
```bash
# Vérifiez que le modèle est installé
ollama list

# Si ce n'est pas le cas, installez-le
ollama pull llama3.2:3b
```

### Problème : L'outil n'est pas reconnu

**Solution :**
1. Vérifiez l'emplacement du plugin : `/home/hauuru/.openclaw/extensions/openclaw-tinyllama-plugin/index.js`
2. Vérifiez que le fichier `index.js` existe
3. Redémarrez OpenClaw : `openclaw gateway restart`

## 📚 Documentation supplémentaire

- **TOOLS.md** : Guide d'utilisation détaillé de l'outil
- **mémoire.md** : Informations opérationnelles et erreurs fréquentes
- **AGENTS_PROMPT.md** : Prompt pour intégrer dans AGENTS.md

## 🎓 Prochaines étapes

1. ✅ Installer le plugin
2. ✅ Tester avec des commandes simples
3. ✅ Lire TOOLS.md pour comprendre les capacités
4. ✅ Consulter mémoire.md pour les erreurs fréquentes
5. ✅ Intégrer le prompt dans AGENTS.md

## 💡 Astuces

- Utilisez des prompts simples et directs
- Précisez le contexte si nécessaire (ex: "dans le dossier /var/log")
- Vérifiez toujours les commandes générées avant exécution
- Pour les commandes complexes, décomposez-les en étapes simples

## 📞 Support

En cas de problème, vérifiez :
1. Ollama est-il en cours d'exécution ?
2. Le modèle llama3.2:3b est-il installé ?
3. Le plugin est-il au bon emplacement ?
4. OpenClaw a-t-il été redémarré après l'installation ?

---

**Version :** 1.0
**Date :** 2026-04-03
**Modèle :** llama3.2:3b
**Plugin :** openclaw-tinyllama-plugin
